export const variablesState = {
  totalItems: 0,
  totalAmount: 0,
};
